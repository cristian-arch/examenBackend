package utils;

public class BemEnums {

	public enum datosDataSource{

		weblogic_jndi("weblogic.jndi.WLInitialContextFactory"),
		name_jndi("JDBC/JDBC_pruebasJNDI"),
		NAME_JNDI2("jdbc/mercadoBanorte"),

		NAME_JNDI3("test");
		String paramDataSource;

		private datosDataSource(String paramDataSource) {
			this.paramDataSource = paramDataSource;
		}
		public String getparamDataSource() {
			return paramDataSource;
		}

	}

	public enum estatusCert{
		LIBRE(1),
		BLOQUEADO(2),
		ASIGNADO(3),
		CANCELADO(4),
		EXPIRADO(5),
		VENCIDO(6),
		REDIMIDO(7),
		DEVUELTO(8),
		BLOQUEADO_POR_SISTEMA(9)
		;
		int paramEstatusCert;

		private estatusCert(int paramEstatusCert) {
			this.paramEstatusCert = paramEstatusCert;
		}
		public int getParamEstatusCert() {
			return paramEstatusCert;
		}
	}
	//------------------------------------------------------------------------------------------------------
	//------------------------------------------------------------------------------------------------------
	public enum cifrado{
		SHA_256("SHA-256");
		String paramCifrado;

		cifrado(String string) {
		}

		public String getParamCifrado() {
			return paramCifrado;
		}

		public void setParamCifrado(String paramCifrado) {
			this.paramCifrado = paramCifrado;
		}
	}

	public enum moduloPagos{
		URL_SECURE3D_DESARROLLO("https://uxm909v1.dev.unix.banorte.com:7306/3dsecure/Solucion3DSecure.htm"),
		URL_SECURE3D_PRODUCCION("https://eps.banorte.com/secure3d/Solucion3DSecure.htm"),
		URL_PAYWORKS2_DESARROLLO("http://15.128.25.221:7095/paywplus/procesadorHttp.htm"),
		URL_PAYWORKS2_PRODUCCION("https://via.pagosbanorte.com/payw2"),
		SHOPPNG_URL_DESARROLLO("http://15.128.1.157/PORTAL3/banorte/mercadobanorte/#/shopping"),
		SHOPPNG_URL_PRODUCCION("https://www.banorte.com/cms/banorte/mercadobanorte/#/shopping"),
		PURCHASE_URL_DESARROLLO("http://15.128.1.157/PORTAL3/banorte/mercadobanorte/#/purchase?status=1"),
		PURCHASE_URL_PRODUCCION("https://www.banorte.com/cms/banorte/mercadobanorte/#/purchase?status=1"),
		HOME_URL_DESARROLLO("http://15.128.1.157/PORTAL3/banorte/mercadobanorte/#/home"),
		HOME_URL_PRODUCCION("https://www.banorte.com/cms/banorte/mercadobanorte/#/home"),
		CERT_3D("03"),
		IDIOMA_RESPUESTA("ES"),
		MODO_PRODUCCION("PRD"),
		MODO_AUTORIZADO("AUT"),
		MODO_DECLINADO("DEC"),
		MODO_ALEATORIO("RND"),
		CMD_VENTA("VENTA"),
		CMD_DEVOLUCION("DEVOLUCION"),
		CMD_REVERSA("REVERSA"),
		MODO_ENTRADA("MANUAL"),
		MENSAJE_ENVIO_3DSECURE_OK("Su pago se encuentra en proceso"),
		MENSAJE_ENVIO_3DSECURE_FAIL("No se pudo enviar a 3dSecure")
		;
		String paramModuloPagos;


		private moduloPagos(String paramModuloPagos) {
			this.paramModuloPagos = paramModuloPagos;
		}

		public String getParamModuloPagos() {
			return paramModuloPagos;
		}

		public void setParamModuloPagos(String paramModuloPagos) {
			this.paramModuloPagos = paramModuloPagos;
		}

	}

	public enum CodigoActivacion{
		Bound(1000);
		int topBound;

		private CodigoActivacion(int topBound) {
			this.topBound = topBound;
		}
		public int getTopBound() {
			return topBound;
		}
	}

	public enum niveles{
		NIVEL2(2),
		NIVEL3(3),
		NIVEL4(4),
		NIVEL5(5),
		;
		int paramNiveles;

		private niveles(int paramNiveles) {
			this.paramNiveles = paramNiveles;
		}
		public int getParamNiveles() {
			return paramNiveles;
		}
	}



	public enum nivelesLog{
		ERROR("Error"),
		NOTIFICACION("Notificacion"),
		ADVERTENCIA("Advertencia");
		String paramNivelesLog;

		nivelesLog(String paramNivelesLog){
			this.paramNivelesLog = paramNivelesLog;
		}

		public String getParamNivelesLog() {
			return paramNivelesLog;
		}

		public void setParamNivelesLog(String paramNivelesLog) {
			this.paramNivelesLog = paramNivelesLog;
		}
	}

	public enum estatusCompra{
		RECHAZADO(1),
		EN_PROCESO(2),
		PROCESADO_POR_3DSECURE_ESPERA_PROCESO_PAYWORKS(3),
		INTENTO_ENVIO_PAYWORKS(4),
		PROCESADO_POR_PAYWORKS(5),
		NO_PROCESADA(6),
		PAGADA_FINALIZADA(7)
		;
		int paramEstatusCompra;

		private estatusCompra(int paramEstatusCompra) {
			this.paramEstatusCompra = paramEstatusCompra;
		}

		public int getParamEstatusCompra() {
			return paramEstatusCompra;
		}

		public void setParamEstatusCompra(int paramEstatusCompra) {
			this.paramEstatusCompra = paramEstatusCompra;
		}
	}

	public enum paramService{

		mensajeExito("Exitoso"),
		mensajeNoexitoso("Error"),
		CODIGO_RESPUESTA_TRUE_SIN_RESULTADOS("1"),
		codigoRespuestaTrue("0"),//RESPUESTA EXITOSA
		codigoRespuestaFalse("-1"),//RESPUESTA FALSE
		mensajeUser("No se encontro el usuario."),
		mensajeUserTrue("se encontro el usuario."),
		mensajeNumeroCertidficadoTrue("se encontro el numero certificado"),
		mensajeNumeroCertidficadoFalse("No se encontro el numero certificado"),
		mensajeCodigoActivacion("No se pudo generar el codigo de activacion. Numero de telefono null"),
		mensajeCodigoActivacionInvalido("Codigo de verificacion invalido"),
		NO_HAY_EXISTENCIAS_NUMEROS_CERTIFICADOS("No se encontraron existencias de este certificado"),
		NO_HAY_NUMEROS_CERTIFICADO_DE_ESTE_CERTIFICADO("No hay registros de este certificado en este carrito"),
		NO_HAY_CERTIFICADOS_EN_CARRITO_DE_USUARIO("No hay productos en el carrito de este usuario"),
		NO_HAY_ORDEN_DE_COMPRA_PARA_ESTE_USUARIO("Este usuario no tiene una orden de compra que pueda ser procesada"),
		INTENTAR_MAS_TARDE("No se pudo realizar el pago, le sugerimos intentarlo mas tarde"),
		PAGO_RECHAZADO("Esta forma de pago fue rechazada, porfavor intentelo con otros datos de pago"),
		SIN_DATOS_PARA_MOSTRAR("No se encontraron datos con este/estos criterios de busqueda"),
		ID_MCAT("1"),
		ID_MCAF("0"),
		MSJ_USUARIO_MCA("Error en el servicio"),
		MSJ_USUARIO_MCAOK("NOTIFICADOR 1 1 EXITOSO");

		String userLogin;

		private paramService(String userLogin) {
			this.userLogin = userLogin;
		}
		public String getParamService() {
			return userLogin;
		}

	}

	public enum manejoArchivos{
		DIRECTORIO_IMAGENES_CERTIFICADOS("c:\\img\\certificados\\"),
		NOMBRE_ARCHIVO_EXCEL("carga_masiva_numeros_certificado.xlsx"),
		FORMATO_JPG(".jpg")
		;

		String manejoArchivos;

		private manejoArchivos(String manejoArchivos) {
			this.manejoArchivos = manejoArchivos;
		}

		public String getManejoArchivos() {
			return manejoArchivos;
		}

		public void setManejoArchivos(String manejoArchivos) {
			this.manejoArchivos = manejoArchivos;
		}
	}

	public enum tiemposConexion{
		TIEMPO_CONEXION_MAXIMO(12000),
		TIEMPO_LECTURA_MAXIMO(12000)
		;

		int tiemposConexion;

		private tiemposConexion(int tiemposConexion) {
			this.tiemposConexion = tiemposConexion;
		}

		public int getTiemposConexion() {
			return tiemposConexion;
		}

		public void setTiemposConexion(int tiemposConexion) {
			this.tiemposConexion = tiemposConexion;
		}
	}
	
	public enum tiposDevolucion{
		TOTAL("TOTAL"),
		PARCIAL("PARCIAL");
		
		String tiposDevolucion;
		
		private tiposDevolucion(String tiposDevolucion) {
			this.tiposDevolucion = tiposDevolucion;
		}
		
		public String getTiposDevolucion() {
			return tiposDevolucion;
		}
				
	}

}
