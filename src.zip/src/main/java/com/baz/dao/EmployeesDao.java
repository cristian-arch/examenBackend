package com.baz.dao;

import com.baz.vo.Empleados;
import com.baz.vo.Employees;
import com.baz.vo.EmployeesVO;
import com.baz.vo.EmployeesWorkedHours;
import com.baz.vo.EmployesCalculos;
import com.baz.vo.Genders;
import com.baz.vo.Job;
import com.baz.vo.reponseVO;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class EmployeesDao {

    PoolDataSourceDao poolDataSourceDao = new PoolDataSourceDao();
    Connection connection = null;


    public reponseVO SaveEmployees(EmployeesVO employeesVO) {


        reponseVO response = new reponseVO();


        try {
            connection = poolDataSourceDao.cargarDataSource();

            if (validarNombreApellido(employeesVO.getName(), employeesVO.getLastName()) == false) {


                if (validar_edad(employeesVO.getBirthate()) == true) {
                    CallableStatement stmt = connection.prepareCall("{call INSERTEMPLOYEES(?,?,?,?,?,?)}");

                    stmt.setInt(1, employeesVO.getId());
                    stmt.setInt(2, employeesVO.getGenderId());
                    stmt.setInt(3, employeesVO.getJobId());

                    stmt.setString(4, employeesVO.getName());
                    stmt.setString(5, employeesVO.getLastName());
                    stmt.setString(6, employeesVO.getBirthate());

                    int opc = stmt.executeUpdate();

                    if (opc == 1) {

                        response.setSucces("true");
                        response.setId(String.valueOf(employeesVO.getId()));
                        response.setStatusRespuesta(true);


                    } else {
                        response.setSucces("false");
                        response.setMensajeRespuesta("No se inserto el empleado");
                        response.setId(null);
                    }
                } else {
                    response.setSucces("false");
                    response.setMensajeRespuesta("el empleado no es mayor de edad ");
                    response.setId(null);
                }
            } else {
                response.setSucces("false");
                response.setMensajeRespuesta("Ya existe un empleado con el mismo nombre o apellido");
                response.setId(null);
            }
        } catch (Exception ex) {

            response.setSucces("false");
            response.setMensajeRespuesta("error " + ex.getMessage());

            response.setId(null);

        }
        return response;
    }


    public boolean validarNombreApellido(String name, String lasName) {

        System.out.println("valida nombre " + name + "  apell ->" + lasName);
        boolean estatus;
        String sentencia = " SELECT * FROM " +
                " employees where name='" + name + "' and last_name='" + lasName + "' ";
        try {
            System.out.println("sentecnia->" + sentencia);
            connection = poolDataSourceDao.cargarDataSource();
            Statement sen = connection.createStatement();
            ResultSet res;
            sen = connection.createStatement();

            res = sen.executeQuery(sentencia);
            if (res.next()) {
                System.out.println("true");
                estatus = true;
            } else {

                estatus = false;
            }
        } catch (Exception ex) {
            estatus = false;
            System.out.println("ex->" + ex.getMessage());
        }

        return estatus;
    }

    public boolean validar_edad(String birthdate) {

        boolean estatus;
        String date = birthdate;


        int edad = 2022 - Integer.parseInt(date.substring(6, 10));

        if (edad >= 18) {
            estatus = true;
        } else {
            estatus = false;
        }


        return estatus;
    }


    public reponseVO SaveEmployeesWorkedHours(EmployeesWorkedHours employeesWorkedHours) {


        reponseVO response = new reponseVO();


        if (employeesWorkedHours.getWorkedHours() <= 20) {

            if (validarFecha(employeesWorkedHours.getWorkedDate()) == true) {


                if (validarEmployeedExistente(employeesWorkedHours.getWorkedDate(), employeesWorkedHours.getEmployeeId()) == false) {

                    System.out.println("entra aqui pporque no estoy registrado ");

                    try {
                        connection = poolDataSourceDao.cargarDataSource();


                        CallableStatement stmt = connection.prepareCall("{call INSERT_EMPLOYEES_WORKED_HOURS(?,?,?,?)}");

                        stmt.setInt(1, employeesWorkedHours.getId());
                        stmt.setInt(2, employeesWorkedHours.getEmployeeId());
                        stmt.setInt(3, employeesWorkedHours.getWorkedHours());

                        stmt.setString(4, employeesWorkedHours.getWorkedDate());


                        int opc = stmt.executeUpdate();

                        if (opc == 1) {

                            response.setSucces("true");
                            response.setId(String.valueOf(employeesWorkedHours.getId()));
                            response.setStatusRespuesta(true);


                        } else {
                            response.setSucces("false");
                            response.setMensajeRespuesta("No se inserto LAS HORAS TRABAJADAS DEL EMPLEADO");
                            response.setId(null);
                        }


                    } catch (Exception ex) {

                        response.setSucces("false");
                        response.setMensajeRespuesta("error " + ex.getMessage());

                        response.setId(null);

                    }

                } else {

                    response.setSucces("false");
                    response.setMensajeRespuesta("Ya existe el empleado  " + employeesWorkedHours.getEmployeeId() + " en esta fecha    " + employeesWorkedHours.getWorkedDate());


                }
            } else {
                response.setSucces("false");
                response.setMensajeRespuesta("Fecha no es menor igual ala actual");

            }
        } else {

            response.setSucces("false");
            response.setMensajeRespuesta("las horas trabajadas no debe ser mayor a 20 horas por dia ");


        }
        return response;
    }


    public boolean validarFecha(String WorkedDate) {

        boolean estatus;
        String sentencia = " SELECT *  " +
                " from employees_worked_hours where '" + WorkedDate + "'<=sysdate ";
        try {
            System.out.println("sentecnia->" + sentencia);
            connection = poolDataSourceDao.cargarDataSource();
            Statement sen = connection.createStatement();
            ResultSet res;
            sen = connection.createStatement();

            res = sen.executeQuery(sentencia);
            if (res.next()) {
                System.out.println("true");
                estatus = true;
            } else {

                estatus = false;
            }
        } catch (Exception ex) {
            estatus = false;
            System.out.println("ex->" + ex.getMessage());
        }

        return estatus;
    }


    public boolean validarEmployeedExistente(String WorkedDate, int idEmployee) {

        boolean estatus;
        String sentencia = " select * from employees_worked_hours where worked_date='" + WorkedDate + "'  and employee_id=" + idEmployee + "";
        try {
            System.out.println("sentecnia->" + sentencia);
            connection = poolDataSourceDao.cargarDataSource();
            Statement sen = connection.createStatement();
            ResultSet res;
            sen = connection.createStatement();

            res = sen.executeQuery(sentencia);
            if (res.next()) {
                System.out.println("true estoy en la tabla regresare true ");
                estatus = true;
            } else {

                estatus = false;
            }
        } catch (Exception ex) {
            estatus = false;
            System.out.println("ex->" + ex.getMessage());
        }

        return estatus;
    }


    public  void ConsultarEmpleadoPorJobs(){




    }

    public Empleados ConsultarEmployeesPorJobs(Job Rewquest){
        Empleados empleados=new Empleados();
        Statement sen = null;
        ResultSet res = null;
        Connection conexion = null;
        Employees employeestest=new Employees();

        System.out.println("1");
        try {
            conexion = poolDataSourceDao.cargarDataSource();
            sen = conexion.createStatement();
            String sentencia = "\n" +
                    "select * from employees em inner join jobs jo on em.job_id=jo.id join genders gen on  em.gender_id=gen.id where jo.id="+Rewquest.getId()+"";
            sen = conexion.createStatement();
            res = sen.executeQuery(sentencia);
            ArrayList<Employees> employeesArrayList= new ArrayList<Employees>();
            Employees employees1=null;
            Genders genders;
            Job job;
            System.out.println("2");
            while(res.next()) {
                System.out.println("3");
                employees1 = new Employees();
                genders = new Genders();
                job = new Job();

                employees1.setId(res.getInt(1));
                employees1.setName(res.getString(4));
                employees1.setLastName(res.getString(5));
                employees1.setBirthate(res.getString(6));
                employees1.setStatusRespuesta(true);

                System.out.println("4");
                ArrayList<Genders> genders1 = new ArrayList<Genders>();
                genders.setId(res.getInt(10));
                genders.setName(res.getString(11));
                genders.setStatusRespuesta(true);
                genders1.add(genders);
                System.out.println("5");
                employees1.setGenders(genders1);


                ArrayList<Job> jobs1 = new ArrayList<Job>();

                System.out.println("6");
                job.setId(res.getInt(7));
                job.setName(res.getString(8));
                job.setSalary(res.getInt(9));

                jobs1.add(job);
                employees1.setJobs(jobs1);

                System.out.println("7");

                employeesArrayList.add(employees1);
            }


            if(employeesArrayList.size()>0) {
                empleados.setEmployees(employeesArrayList);
                empleados.setSucces(true);
            }else{
                empleados.setEmployees(employeesArrayList);
                empleados.setSucces(false);
            }



        }catch (Exception e) {
            empleados.setEmployees(null);
            empleados.setSucces(false);
            System.out.println("esss->"+e.getMessage());

            }finally {
            poolDataSourceDao.closeConn(conexion);
            poolDataSourceDao.closeST(sen);
            poolDataSourceDao.closeRS(res);
        }


return  empleados;

    }

    public EmployesCalculos totalWorkedHours(EmployesCalculos employesCalculos) {

        EmployesCalculos employesCalculosResponse=new EmployesCalculos();

        boolean estatus;
        String sentencia = " select sum(worked_hours) as horasTrabajadas from employees_worked_hours ew where ew.employee_id ="+employesCalculos.getEmployeeId()+" and ew.worked_date>='"+employesCalculos.getStartDate()+"' and ew.worked_date<='"+employesCalculos.getEndDate()+"' ";
        try {
            System.out.println("sentecnia->" + sentencia);
            connection = poolDataSourceDao.cargarDataSource();
            Statement sen = connection.createStatement();
            ResultSet res;
            sen = connection.createStatement();
             res = sen.executeQuery(sentencia);
            if (res.next()) {
                System.out.println("calcularHorasPorId ");
                estatus = true;
                employesCalculosResponse.setTotal_workedHours(res.getInt(1));

                employesCalculosResponse.setSucces(true);
            } else {

                estatus = false;
                employesCalculosResponse.setSucces(false);
            }
        } catch (Exception ex) {
            estatus = false;
            employesCalculosResponse.setSucces(false);
            System.out.println("ex->" + ex.getMessage());
        }

        return employesCalculosResponse;
    }


    public EmployesCalculos payment(EmployesCalculos employesCalculos) {

        EmployesCalculos employesCalculosResponse=new EmployesCalculos();

        boolean estatus;
        String sentencia = "select (sum(worked_hours)  * j.salary ) from employees_worked_hours ew inner join employees emp on emp.id=ew.employee_id  " +
                " inner join  jobs j on j.id=emp.job_id where ew.employee_id ="+employesCalculos.getEmployeeId()+" and ew.worked_date>='"+employesCalculos.getStartDate()+"'"+
                " and ew.worked_date<='"+employesCalculos.getEndDate()+"'  GROUP BY  emp.job_id ,j.salary\n" +
                "\n";
        try {
            System.out.println("sentecnia->" + sentencia);
            connection = poolDataSourceDao.cargarDataSource();
            Statement sen = connection.createStatement();
            ResultSet res;
            sen = connection.createStatement();
            res = sen.executeQuery(sentencia);
            if (res.next()) {
                System.out.println("calcularHorasPorId ");
                estatus = true;
                employesCalculosResponse.setPayment(res.getInt(1));

                employesCalculosResponse.setSucces(true);
            } else {

                estatus = false;
                employesCalculosResponse.setSucces(false);
            }
        } catch (Exception ex) {
            estatus = false;
            employesCalculosResponse.setSucces(false);
            System.out.println("ex->" + ex.getMessage());
        }

        return employesCalculosResponse;
    }




}
