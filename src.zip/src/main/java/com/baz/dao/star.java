package com.baz.dao;

public class star {
    public static void main(String args[]){

        String date="18-03-1994";

        System.out.println(""+date.substring(6,10));

        int edad=2022-Integer.parseInt(date.substring(6,10));
        System.out.println("edad"+edad);

    }



}
