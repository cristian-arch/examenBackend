package com.baz.dao;

import utils.BemEnums;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import java.sql.*;
import java.util.Hashtable;
import java.util.logging.Logger;


public class PoolDataSourceDao {

    private Connection connection=null;
    private static final Logger logger = Logger.getLogger(PoolDataSourceDao.class.getName());


    public Connection cargarDataSource() throws NamingException, SQLException {
            Hashtable env = new Hashtable();
            env.put(Context.INITIAL_CONTEXT_FACTORY, BemEnums.datosDataSource.weblogic_jndi.getparamDataSource());
            InitialContext ctx = new InitialContext(env);
            javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(BemEnums.datosDataSource.NAME_JNDI3.getparamDataSource());
            Connection con= ds.getConnection();
            return con;
    }
    

	public Connection cargarDataSourceSqlServer() throws Exception{
        Hashtable env = new Hashtable();
        env.put(Context.INITIAL_CONTEXT_FACTORY, BemEnums.datosDataSource.weblogic_jndi.getparamDataSource());
        InitialContext ctx = new InitialContext(env);
        javax.sql.DataSource ds = (javax.sql.DataSource) ctx.lookup(BemEnums.datosDataSource.NAME_JNDI2.getparamDataSource());
        Connection con= ds.getConnection();
        return con;
    }

    public void closeConn(Connection con){
        try {
            if(con!=null)
                con.close();
            con=null;
        } catch (SQLException e) {
            logger.log(java.util.logging.Level.SEVERE, "Error al insertar en BD MERCADO BANORTE:  " + e.toString(), e);
        }
    }

    public void closePST(PreparedStatement pstmt){
        try {
            if(pstmt!=null)
                pstmt.close();
            pstmt=null;
        } catch (SQLException e) {
            logger.log(java.util.logging.Level.SEVERE, "Error al insertar en BD MERCADO BANORTE: " + e.toString(), e);
        }
    }
    public void closeRS(ResultSet resultSet){
        try {
            if(resultSet!=null)
                resultSet.close();
            resultSet=null;
        } catch (SQLException e) {
            logger.log(java.util.logging.Level.SEVERE, "Error al insertar en BD MERCADO BANORTE: " + e.toString(), e);
        }
    }
    public void closeST(Statement statement){
        try {
            if(statement!=null)
                statement.close();
            statement=null;
        } catch (SQLException e) {
            logger.log(java.util.logging.Level.SEVERE, "Error al insertar en BD MERCADO BANORTE: " + e.toString(), e);
        }
    }
}
