package com.baz.dao;

import com.baz.vo.BatchResponse;
import com.baz.vo.Genders;

import java.sql.CallableStatement;
import java.sql.Connection;

public class GendersDAO extends BatchResponse {

    PoolDataSourceDao poolDataSourceDao = new PoolDataSourceDao();
    Connection connection=null;

    public Genders saveGenders(Genders genders){

        GendersDAO gendersDAO=new GendersDAO();

        try {


            System.out.println("prueba insertar es xxxxx ");
            System.out.println("entes es ");
            connection= poolDataSourceDao.cargarDataSource();
            System.out.println("2a");
            CallableStatement stmt=connection.prepareCall("{call INSERGENDERS(?,?)}");
            stmt.setInt(1,genders.getId());
            System.out.println("2");
            stmt.setString(2,genders.getName());
            stmt.execute();
            System.out.println("3");


            System.out.println("success obtener con int ");


            genders.setMensajeRespuesta("exitoso");


        }
        catch (Exception ex)  {
            ex.printStackTrace();
            System.out.println("execcc-Ç>"+ex.getMessage());
            genders.setMensajeRespuesta("no exitoso");
        }
        return genders;


    }






}
