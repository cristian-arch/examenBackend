package com.baz.vo;

public class EmployeesVO extends BatchResponse{


    int  Id;
    int GenderId;
    int JobId;
    String Name;
    String LastName;
    String Birthate;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getGenderId() {
        return GenderId;
    }

    public void setGenderId(int genderId) {
        GenderId = genderId;
    }

    public int getJobId() {
        return JobId;
    }

    public void setJobId(int jobId) {
        JobId = jobId;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getBirthate() {
        return Birthate;
    }

    public void setBirthate(String birthate) {
        Birthate = birthate;
    }
}
