package com.baz.vo;

import java.util.ArrayList;

public class Employees extends BatchResponse{


    int  Id;
    String Name;
    String LastName;
    String Birthate;

    private ArrayList<Job> jobs;

    private ArrayList<Genders> genders;

    public ArrayList<Job> getJobs() {
        return jobs;
    }

    public void setJobs(ArrayList<Job> jobs) {
        this.jobs = jobs;
    }

    public ArrayList<Genders> getGenders() {
        return genders;
    }

    public void setGenders(ArrayList<Genders> genders) {
        this.genders = genders;
    }

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }


    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getBirthate() {
        return Birthate;
    }

    public void setBirthate(String birthate) {
        Birthate = birthate;
    }
}
