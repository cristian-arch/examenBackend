package com.baz.vo;

import java.util.ArrayList;

public class Empleados {

    private ArrayList<Employees> Employees=new ArrayList<>();
    boolean succes;

    public ArrayList<com.baz.vo.Employees> getEmployees() {
        return Employees;
    }

    public void setEmployees(ArrayList<com.baz.vo.Employees> employees) {
        Employees = employees;
    }

    public boolean isSucces() {
        return succes;
    }

    public void setSucces(boolean succes) {
        this.succes = succes;
    }
}
