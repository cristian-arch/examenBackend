package com.baz.vo;

public class EmployesCalculos {

    int employeeId;
    String startDate;
    String endDate;
    int total_workedHours;
    boolean succes;

    int payment;

    public int getPayment() {
        return payment;
    }

    public void setPayment(int payment) {
        this.payment = payment;
    }



    public int getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(int employeeId) {
        this.employeeId = employeeId;
    }



    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public int getTotal_workedHours() {
        return total_workedHours;
    }

    public void setTotal_workedHours(int total_workedHours) {
        this.total_workedHours = total_workedHours;
    }

    public boolean isSucces() {
        return succes;
    }

    public void setSucces(boolean succes) {
        this.succes = succes;
    }
}
