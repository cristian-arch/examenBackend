package com.baz.vo;

public class EmployeesWorkedHours {

    int Id;
    int EmployeeId;
    int WorkedHours;
    String WorkedDate;

    public int getId() {
        return Id;
    }

    public void setId(int id) {
        Id = id;
    }

    public int getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(int employeeId) {
        EmployeeId = employeeId;
    }

    public int getWorkedHours() {
        return WorkedHours;
    }

    public void setWorkedHours(int workedHours) {
        WorkedHours = workedHours;
    }

    public String getWorkedDate() {
        return WorkedDate;
    }

    public void setWorkedDate(String workedDate) {
        WorkedDate = workedDate;
    }
}
