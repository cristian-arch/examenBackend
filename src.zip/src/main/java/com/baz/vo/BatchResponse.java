package com.baz.vo;

public class BatchResponse {
    String MensajeRespuesta;
    Boolean StatusRespuesta;


    public String getMensajeRespuesta() {
        return MensajeRespuesta;
    }

    public void setMensajeRespuesta(String mensajeRespuesta) {
        MensajeRespuesta = mensajeRespuesta;
    }

    public Boolean getStatusRespuesta() {
        return StatusRespuesta;
    }

    public void setStatusRespuesta(Boolean statusRespuesta) {
        StatusRespuesta = statusRespuesta;
    }
}
