package com.baz.service;

import com.baz.dao.EmployeesDao;
import com.baz.dao.GendersDAO;
import com.baz.vo.Empleados;
import com.baz.vo.EmployeesVO;
import com.baz.vo.EmployeesWorkedHours;
import com.baz.vo.EmployesCalculos;
import com.baz.vo.Genders;
import com.baz.vo.Job;
import com.baz.vo.reponseVO;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/api")
public class EmployeesRestService {

    GendersDAO gendersDAO = new GendersDAO();
    EmployeesDao employeesDao = new EmployeesDao();


    @POST
    @Path("/SaveGenders")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Genders SaveGenders(Genders genders) {

        System.out.println("antes");
        return gendersDAO.saveGenders(genders);
    }

    @POST
    @Path("/SaveEmployees")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public reponseVO SaveEmployees(EmployeesVO employeesVO) {

        return employeesDao.SaveEmployees(employeesVO);
    }


    @POST
    @Path("/SaveEmployeesWorkedHour")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public reponseVO SaveEmployeesWorkedHour(EmployeesWorkedHours employeesWorkedHours) {

        return employeesDao.SaveEmployeesWorkedHours(employeesWorkedHours);
    }

    @POST
    @Path("/SelectEmployeesorJobs")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public Empleados SelectEmployeesorJobs(Job job) {

        System.out.println("entra a qi con data ->" + job);
        return employeesDao.ConsultarEmployeesPorJobs(job);
    }

    @POST
    @Path("/TotalWorkedHours")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public EmployesCalculos TotalWorkedHours(EmployesCalculos employesCalculos) {

        return employeesDao.totalWorkedHours(employesCalculos);
    }


    @POST
    @Path("/payment")
    @Consumes({MediaType.APPLICATION_JSON})
    @Produces({MediaType.APPLICATION_JSON})
    public EmployesCalculos payment(EmployesCalculos employesCalculos) {

        return employeesDao.payment(employesCalculos);
    }




}
