





************************************************************************************* 
*************************************************************************************

CREATE TABLE GENDERS(
ID NUMBER NOT NULL,
NAME VARCHAR2(255)
);

ALTER TABLE GENDERS add CONSTRAINT GENDERS_pk PRIMARY KEY (ID);


CREATE SEQUENCE GENDERS_id_seq  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE OR REPLACE TRIGGER GENDERS_id_trigger
BEFORE INSERT ON GENDERS 
FOR EACH ROW

BEGIN
  SELECT GENDERS_id_seq.NEXTVAL
  INTO   :new.id 
  FROM   dual;
END;


*************************************************************************************
*************************************************************************************



CREATE TABLE JOBS(
ID NUMBER NOT NULL,
NAME VARCHAR2(255),
SALARY NUMBER(9,2)
);  



ALTER TABLE JOBS add CONSTRAINT JOBS_pk PRIMARY KEY (ID);


CREATE SEQUENCE JOBS_id_seq  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE OR REPLACE TRIGGER JOBS_id_trigger
BEFORE INSERT ON JOBS 
FOR EACH ROW

BEGIN
  SELECT JOBS_id_seq.NEXTVAL
  INTO   :new.id 
  FROM   dual;
END;


*************************************************************************************
******************************************************************************************



CREATE TABLE EMPLOYEES(
ID NUMBER,
GENDER_ID NUMBER ,
JOB_ID NUMBER,
NAME VARCHAR2(255),
LAST_NAME VARCHAR2(255),
BIRTHDATE DATE
);


ALTER TABLE EMPLOYEES add CONSTRAINT EMPLOYEES_pk PRIMARY KEY (ID);

CREATE SEQUENCE EMPLOYEES_id_seq  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE OR REPLACE TRIGGER EMPLOYEES_id_trigger
BEFORE INSERT ON EMPLOYEES 
FOR EACH ROW

BEGIN
  SELECT EMPLOYEES_id_seq.NEXTVAL
  INTO   :new.id 
  FROM   dual;
END;


ALTER TABLE EMPLOYEES
add 
    CONSTRAINT fk_GENDER_id
    FOREIGN KEY (GENDER_ID)
    REFERENCES GENDERS(ID);


ALTER TABLE EMPLOYEES
add 
    CONSTRAINT fk_JOBS_id
    FOREIGN KEY (JOB_ID)
    REFERENCES JOBS(ID);




*************************************************************************************
*************************************************************************************


CREATE TABLE EMPLOYEES_WORKED_HOURS(

    ID NUMBER,
    EMPLOYEE_ID NUMBER,
    WORKED_HOURS NUMBER,
    WORKED_DATE  DATE 

    );



ALTER TABLE EMPLOYEES_WORKED_HOURS add CONSTRAINT JEMPLOYEES_WORKED_HOURS_pk PRIMARY KEY (ID);


CREATE SEQUENCE EMPLOYEES_WORKED_HOURS_id_seq  MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE ;

CREATE OR REPLACE TRIGGER EMPLOYEES_WORKED_HOURS_id_trigger
BEFORE INSERT ON EMPLOYEES_WORKED_HOURS 
FOR EACH ROW

BEGIN
  SELECT EMPLOYEES_WORKED_HOURS_id_seq.NEXTVAL
  INTO   :new.id 
  FROM   dual;
END;




ALTER TABLE EMPLOYEES_WORKED_HOURS
add 
    CONSTRAINT fk_EMPLOYEES_id
    FOREIGN KEY (EMPLOYEE_ID)
    REFERENCES EMPLOYEES(ID);


*************************************************************************************
*************************************************************************************


  CREATE OR REPLACE PROCEDURE INSERTEMPLOYEES

(in_id IN NUMBER,
 in_gender_id IN NUMBER,
 in_job_id IN NUMBER,
 in_name IN VARCHAR2,
 in_last_name IN VARCHAR2,
 in_birthdate IN DATE

 )
IS
BEGIN
  INSERT INTO EMPLOYEES 
  values (in_id,in_gender_id,in_job_id,in_name,in_last_name,in_birthdate);
  
  
  

END;



execute INSERTEMPLOYEES(10,1,1,'test','test 2','18/03/1993');


*************************************************************************************
*************************************************************************************

    CREATE OR REPLACE PROCEDURE INSERT_EMPLOYEES_WORKED_HOURS

(in_id IN NUMBER,
 in_EMPLOYEE_ID IN NUMBER,
 in_WORKED_HOURS IN NUMBER,
 in_WORKED_DATE IN VARCHAR2
)
IS
BEGIN
  INSERT INTO employees_worked_hours (ID,
EMPLOYEE_ID,
WORKED_HOURS,
WORKED_DATE)
  values (in_id,in_EMPLOYEE_ID,in_WORKED_HOURS,in_WORKED_DATE);
  

END;


select * from employees_worked_hours;
execute INSERT_EMPLOYEES_WORKED_HOURS(10,1,10,'18/03/1993');



*************************************************************************************
*************************************************************************************



select * from employees em inner join jobs jo on em.job_id=jo.id join genders gen on  em.gender_id=gen.id where jo.id=2;


select * from employees_worked_hours;


select sum(worked_hours) from employees_worked_hours ew where ew.employee_id =1 and ew.worked_date>='18-03-22' and ew.worked_date<=sysdate ;


select sum(worked_hours) as horasTrabajadas from employees_worked_hours ew where ew.employee_id =1 and ew.worked_date>='23-06-22' and ew.worked_date<='24-06-22' ;

select (sum(worked_hours)  * j.salary ) from employees_worked_hours ew inner join employees emp on emp.id=ew.employee_id   inner join  jobs j on j.id=emp.job_id where ew.employee_id =1 and ew.worked_date>='20-12-20' and ew.worked_date<='24-06-22'  GROUP BY  emp.job_id ,j.salary










































